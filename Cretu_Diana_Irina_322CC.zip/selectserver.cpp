#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fstream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <iostream>
#include <unistd.h>
#include <sstream>
#include <string.h>
#include <algorithm>

#define MAX_CLIENTS	5
#define BUFLEN 256

#include <vector>

using namespace std;

//Structura in care avem datele clientului
struct Intrari {
 	char nume[12];
 	char prenume[12];
 	long int nr_card;
 	int pin;
 	char parola[8];
 	double sold;
 	bool blocat;
 	bool conectat;
};

vector<Intrari> v;

void read_input(char *f) {
    ifstream fin(f);
    int n;
    fin >> n;
    for (int i = 0; i < n; i++) {
     	struct Intrari intr;
     	fin >> intr.nume >> intr.prenume >> intr.nr_card >> intr.pin >> intr.parola >> intr.sold;
     	intr.blocat = false;
     	intr.conectat = false;
     	v.push_back(intr);
    }
	fin.close();
}

void error(char *msg)
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
    int sockfd, newsockfd, portno;
    socklen_t clilen;
    char buffer[BUFLEN];
    struct sockaddr_in serv_addr, cli_addr;
    int n, i, j;

    fd_set read_fds;	// multimea de citire folosita in select()
    fd_set tmp_fds;	   // multime folosita temporar 
    int fdmax;		  // valoare maxima file descriptor din multimea read_fds

    if (argc < 2) {
        fprintf(stderr,"Usage : %s port\n", argv[0]);
        exit(1);
    }

    read_input(argv[2]);

    //golim multimea de descriptori de citire (read_fds) si multimea tmp_fds 
    FD_ZERO(&read_fds);
    FD_ZERO(&tmp_fds);
     
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
    	error("ERROR opening socket");
    }
    portno = atoi(argv[1]);

    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;	// foloseste adresa IP a masinii
    serv_addr.sin_port = htons(portno);
     
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr)) < 0) {
		error("ERROR on binding");
    }
    listen(sockfd, MAX_CLIENTS);

    // adaugam noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
    FD_SET(sockfd, &read_fds);
    // adaugam stdin pt quit
    FD_SET(0, &read_fds);
    fdmax = sockfd;
    bool esteLogat = false;
    bool alreadyConnected = false;
    int usernameCurrent = -1;
    vector<int> usernameLoggat(fdmax, -1);
    int nr_incercari = 0;
    vector<bool> socketConneted(fdmax, false);
    double suma = 0;
    int nr_card = 0;
    bool transferAcum = false;
    vector<int> incercariSock(10000, 0);
    for (int i = 0; i < 10000; i++) {
    	incercariSock[i] = 0;
    }
    char iesire[1000];
    int ok = 0;
	while (1) {
		tmp_fds = read_fds; 
		if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) { 
			error("ERROR in select");
		}
		
		for(i = 0; i <= fdmax; i++) {

			if (FD_ISSET(i, &tmp_fds)) {
			
				// Primeste quit de la stdin serverul
				if (i == 0) {

		 			memset(iesire, 0, 1000);
					fgets(iesire, 999, stdin);
					iesire[strcspn(iesire, "\n")] = '\0';
					if (strcmp(iesire,"quit") == 0) {
						socketConneted[i] = false;
			            for (int k = 0; k < v.size(); k ++) {
			   				if (v[k].nr_card == usernameLoggat[i]) {
			       				v[k].conectat = false;
			            	}
		     			}
	           			usernameLoggat[i] = -1;
						string s = "IBANK> Serverul se va inchide.\n";
				        ok = 1;
				        strcpy(buffer, s.c_str());
						printf ("Am primit de la clientul de pe socketul %d, mesajul: %s\n", i, buffer);
						printf("IBANK> trimit mesajul inapoi\n");
						for(int j = 0; j <= fdmax; j++) {
							if (j != sockfd) {
								send(j, buffer, strlen(buffer), 0);
							}
						}
				        break;
				    }

				}
				if (i == sockfd) {
					// a venit ceva pe socketul inactiv(cel cu listen) = o noua conexiune
					// actiunea serverului: accept()
					clilen = sizeof(cli_addr);
					if ((newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen)) == -1) {
						error("ERROR in accept");
					} 
					else {
						//adaug noul socket intors de accept() la multimea descriptorilor de citire
						FD_SET(newsockfd, &read_fds);
						if (newsockfd > fdmax) { 
							fdmax = newsockfd;
						}
					}
					printf("Noua conexiune de la %s, port %d, socket_client %d\n ", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), newsockfd);
				}
					
				else {
					// am primit date pe unul din socketii cu care vorbesc cu clientii
					// actiunea serverului: recv()
					memset(buffer, 0, BUFLEN);
					if ((n = recv(i, buffer, sizeof(buffer), 0)) <= 0) {
						if (n == 0) {
							//conexiunea s-a inchis
							printf("selectserver: socket %d hung up\n", i);
						} else {
							error("ERROR in recv");
						}
						close(i); 
						FD_CLR(i, &read_fds); // scoatem din multimea de citire socketul pe care 
					} 
					
					else {
						// parsam mesajul primit de la client
						string str1(buffer);
						istringstream iss(str1);
						string word;
						iss >> word;
						string s;
						// Userul se loggeaza
						if (word == "login") {
							
							int username, parola;
							iss >> username;
							iss >> parola;
							cout << endl;
							cout << "parola e " << username;
							cout << endl;

							// Nu mai este nimeni conectat pe socket
							if (socketConneted[i] == false ) {
								int k;
								for (k = 0; k < v.size(); k ++) {
									if (v[k].nr_card == username){
										break;
									}
								}
								if (k == v.size()) {
									s = "IBANK> -4 : Numar card inexistent.\n";
								}
								else {
									if (v[k].blocat == true) {
										s = "IBANK> -5: Card blocat.\n";
									}
									else {
										// Utilizatorului acestui card nu e logat pe alt socket
										if (v[k].conectat == false) {
											// Parola este corecta => se autentifica
											if (v[k].pin == parola) {
												s = "IBANK> Welcome, ";
												s = s + v[k].nume + " " + v[k].prenume + "!\n";
												esteLogat = true;
												usernameLoggat[i] = username;
												v[k].conectat = true;
												socketConneted[i] = true;
												incercariSock[i] = 0;
					            			}
					            			else {
					            				// Daca s-a schimbat utilizatorul
					            				if (usernameCurrent != username) {
					            					nr_incercari = 1;
					            					incercariSock[i] = 1;
					            					s = "IBANK> -3 : Pin gresit.\n";
					            				}
					            				else {
					            					nr_incercari ++;
					            					incercariSock[i] ++;
					            					if (incercariSock[i] == 3) {
					            						s = "IBANK> -5 : Card blocat.\n";
					            						v[k].blocat = true;
					            					}
					            					else {
					            						s = "IBANK> -3 : Pin gresit.\n";
					            					}
					            				}
					            				usernameCurrent = username;
					            			}
					            		}
					            		else {
					            			s = "IBANK> -2 : Sesiune deja deschisa.\n";
					            		}
				            		}
			            		}
			            	}
			            	// Este logat altcineva
			            	else {

			            		s = "IBANK> -2 : Sesiune deja deschisa.\n";
			            	}
			            }
			            else {
			            	// Daca nu e niciun client loggat si se incearca o alta comanda
			            	if (socketConneted[i] == false) {
			            		s = "-1 : Clientul nu este autentificat.\n";
			            	}
			            	else {
			            		if (word == "logout"){
			            			socketConneted[i] = false;
			            			for (int k = 0; k < v.size(); k ++) {
			            				if (v[k].nr_card == usernameLoggat[i]) {
			            					v[k].conectat = false;
			            				}
			            			}
			            			usernameLoggat[i] = -1;
			            			s = "IBANK> Clientul a fost deconectat.\n";
			            		}
			            		else {
			            			if (word == "listsold") {
			            				if (usernameLoggat[i] != -1) {
			            					double value;
			            					for (int k = 0; k < v.size(); k ++) {
			            						if (v[k].nr_card == usernameLoggat[i]) {
			            							//value = (int) (v[k].sold * 100.0)/100.0; 
			            							value = v[k].sold;
			            						}
			            					}
			            					char nr[10];
			            					sprintf(nr, "%.2f", value);
			            					s = "IBANK> ";
			            					s = s + nr + "\n";
			            				}
			            			}
			            			else {
			            				if (word == "transfer") {
			            					transferAcum = true;
											iss >> nr_card;
											iss >> suma;
											int k;
											// Persoana careia ii transferam
											for (k = 0; k < v.size(); k ++) {
												if (v[k].nr_card == nr_card){
													break;
												}
											}
											if (k == v.size()) {
												s = "IBANK> -4 : Numar card inexistent.\n";
											}
											else {
												// Persoana care transfera
												int index;
												for (index = 0; index < v.size(); index ++) {
													if (v[index].nr_card == usernameLoggat[i]){
														break;
													}
												}
												if (suma > v[index].sold) {
													s = "IBANK> −8 : Fonduri insuficiente.\n";
												}
												else {
													s = "IBANK> Transfer";
													char sumaC[15];
													sprintf(sumaC, "%.15g", suma);
													s = s + " " + sumaC + " catre " + v[k].nume + " " + v[k].prenume + "? [y/n]";
												}
											}	
			            				}
			            				else {
			            					
			            					if (word == "y") {

			            						if (transferAcum == true) {
			            							
			            							// Persoana careia ii transferam
			            							int k;
													for (k = 0; k < v.size(); k ++) {
														if (v[k].nr_card == nr_card){
															break;
														}
													}
													if (k != v.size()) {
			            								v[k].sold = v[k].sold + suma;

			            								// Persoana care transfera
				            							int index;
														for (index = 0; index < v.size(); index ++) {
															if (v[index].nr_card == usernameLoggat[i]){
																break;
															}
														}
														v[index].sold = v[index].sold - suma;
				            							transferAcum = false;
				            							s = "IBANK> Transfer realizat cu succes.\n";
				            						}
				            						else {
				            							s = "NU";
				            						}
			            						}
			            					}
			            					else {
			            						if (transferAcum == true) {
			            							s = "IBANK> -9 : Operatie anulata.\n";
			            						}
			            						else {
			            							if (word == "quit") {
			            								socketConneted[i] = false;
											            for (int k = 0; k < v.size(); k ++) {
											   				if (v[k].nr_card == usernameLoggat[i]) {
											       				v[k].conectat = false;
											            	}
										     			}
									           			usernameLoggat[i] = -1;
									           			//continue;
			            							}
			            						}
			            					}
			            				}
			            			}
			            		}
			            	}
			            }
			            cout << s;
	            		strcpy(buffer, s.c_str());
						printf ("Am primit de la clientul de pe socketul %d, mesajul: %s\n", i, buffer);
	            		printf("IBANK> trimit mesajul inapoi\n");
	            		send(i, buffer, strlen(buffer), 0);
					}
				} 
			}
		}
		if (ok == 1) {
			break;
		}
    }

	close(sockfd);
   
	return 0; 
}
