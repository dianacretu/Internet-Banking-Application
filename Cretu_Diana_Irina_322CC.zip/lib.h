#ifndef LIB
#define LIB

#include <vector>

using namespace std;

struct Intrari {
  char nume[12];
  char prenume[12];
  long int nr_card;
  int pin;
  char parola[8];
  double sold;
  //Intrari(char nume[12], char prenume[12], long int nr_card, int pin, char parola[8], int _sold)
    //    : nume[12], char prenume[12], long int nr_card, int pin, char parola[8], int _sold);
};


vector<Intrari> v;

#endif